package design_pattern.adapter;

public interface Electronic220v {

    void power220vOn();

}
