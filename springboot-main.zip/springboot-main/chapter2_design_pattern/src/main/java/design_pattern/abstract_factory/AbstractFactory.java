package design_pattern.abstract_factory;

public interface AbstractFactory {

    AbstractObject createObject();

}
