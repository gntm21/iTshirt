package design_pattern.abstract_factory;

public interface AbstractObject {

    void print();

}
