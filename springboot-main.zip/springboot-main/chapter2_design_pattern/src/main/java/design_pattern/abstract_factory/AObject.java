package design_pattern.abstract_factory;

public class AObject implements AbstractObject{

    public void print() {
        System.out.println("A Object가 사용되었습니다.");
    }
}
