package design_pattern.proxy;

public interface Service {

    void print();

}
