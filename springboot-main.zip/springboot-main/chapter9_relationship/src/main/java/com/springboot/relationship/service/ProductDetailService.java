package com.springboot.relationship.service;

public interface ProductDetailService {

}
