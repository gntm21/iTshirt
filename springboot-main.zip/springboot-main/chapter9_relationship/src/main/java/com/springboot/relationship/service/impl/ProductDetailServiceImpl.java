package com.springboot.relationship.service.impl;

import com.springboot.relationship.service.ProductDetailService;

public class ProductDetailServiceImpl implements ProductDetailService {

}
