package com.springboot.advanced_jpa.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

// 예제 8.41
@Configuration
@EnableJpaAuditing
public class JpaAuditingConfiguration {

}
