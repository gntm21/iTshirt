package com.springboot.advanced_jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdvancedJpaApplicationTests {

    @Test
    void contextLoads() {
    }

}
