package com.springboot.valid_exception.data.group;

// 예제 10.5
public interface ValidationGroup2 {

}
